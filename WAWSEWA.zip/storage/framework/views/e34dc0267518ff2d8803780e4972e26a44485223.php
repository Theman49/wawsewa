<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="flex flex-col gap-10">
    <div class="container">
        <section id="category" class="border rounded-lg border-gray-200 p-5">
            <p class="text-xl font-bold mb-5">Kategori Pilihan</p>
            <div class="flex gap-10">
                <div class="flex flex-col items-center gap-4 w-full">
                    <div class="rounded-lg bg-gray-200 h-[160px] w-full">
                        <!-- <img src="<?php echo e(Vite::asset('resources/images/cover-barang.png')); ?>" alt="" class="w-full h-full"> -->
                    </div>
                    <p class="text-base font-regular">Elektronik</p>
                </div>
                <div class="flex flex-col items-center gap-4 w-full">
                    <div class="rounded-lg bg-gray-200 h-[160px] w-full">
                        <!-- <img src="<?php echo e(Vite::asset('resources/images/cover-jasa.png')); ?>" alt="" class="w-full h-full"> -->
                    </div>
                    <p class="text-base font-regular">Jasa</p>
                </div>
                <div class="flex flex-col items-center gap-4 w-full">
                    <div class="rounded-lg bg-gray-200 h-[160px] w-full">
                        <!-- <img src="<?php echo e(Vite::asset('resources/images/cover-tempat.png')); ?>" alt="" class="w-full h-full"> -->
                    </div>
                    <p class="text-base font-regular">Tempat</p>
                </div>
                <div class="flex flex-col items-center gap-4 w-full">
                    <div class="rounded-lg bg-gray-200 h-[160px] w-full">
                        <!-- <img src="<?php echo e(Vite::asset('resources/images/cover-kendaraan.png')); ?>" alt="" class="w-full h-full"> -->
                    </div>
                    <p class="text-base font-regular">Usaha</p>
                </div>
                <div class="flex flex-col items-center gap-4 w-full">
                    <div class="rounded-lg bg-gray-200 h-[160px] w-full">
                        <!-- <img src="<?php echo e(Vite::asset('resources/images/cover-kendaraan.png')); ?>" alt="" class="w-full h-full"> -->
                    </div>
                    <p class="text-base font-regular">Kendaraan</p>
                </div>
            </div>
        </section>
    </div>

    <div class="flex gap-10 container">
        <div class="rounded-lg bg-gray-200 w-3/5 h-[332px]"></div>
        <div class="flex flex-col gap-5 w-2/5">
            <div class="rounded-lg bg-gray-200 w-full h-full"></div>
            <div class="rounded-lg bg-gray-200 w-full h-full"></div>
        </div>
    </div>

    <!-- <div class="flex flex-col gap-5 container border rounded-lg border-gray-200 py-5 px-4">
        <div class="flex items-center justify-between">
            <p class="text-xl font-bold">Kategori</p>
            <a href="#" class="text-md font-regular text-primary-500">Semua Kategori</a>
        </div>
        <div class="grid grid-cols-9 gap-5">
            <?php for($i=0; $i<18; $i++): ?>
            <div class="flex flex-col gap-2 w-fit text-center">
                <div class="bg-gray-200 rounded-lg h-[100px] w-[100px] mx-2.5"></div>
                <p class="text-base font-regular">elektronik</p>
            </div>
            <?php endfor; ?>
        </div>
    </div> -->

    <div class="container flex flex-col gap-5 p-8 border rounded-lg border-gray-200">
        <div class="rounded-lg bg-gray-200 w-full h-[250px]">

        </div>

        <div class="flex justify-between flex-start">
            <div>
                <p class="text-xl font-semibold">Produk Terlaris</p>
                <p class="text-sm text-center">Lorem ipsum dolor sit amet consectetur.</p>
            </div>
            <a href="#" class="text-md font-medium text-primary-500">Lihat Semua</a>
        </div>

        <div class="grid grid-cols-5 gap-x-4 gap-y-8">
            <?php for($i=0; $i<10; $i++): ?>
            <?php $__env->startComponent('components/card'); ?>
            <?php echo $__env->renderComponent(); ?>
            <?php endfor; ?>
        </div>
    </div>

    <!-- BANNER -->
    <div class="container">
        <div class="rounded-lg bg-gray-200 w-full h-[250px]">
    </div>

    </div>
    <!-- END BANNER -->

    <!-- <div class="container flex flex-col gap-5 p-8 border border-gray-200 rounded-lg">
        <div class="flex justify-between items-center">
            <p class="text-xl font-bold">Kamera</p>
            <a href="#" class="text-md font-medium text-primary-500">Lihat Semua</a>
        </div>
        <div class="grid grid-cols-4 gap-4">
            <?php for($i=0; $i<4; $i++): ?>
                <?php echo $__env->make('../components/card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endfor; ?>
        </div>
    </div> -->
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.section-card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('section-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('heading', null, []); ?> 
            Kamera
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.section-card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('section-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('heading', null, []); ?> 
            Laptop
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/theman49/Project/WAWSEWA/resources/views/pages/home.blade.php ENDPATH**/ ?>