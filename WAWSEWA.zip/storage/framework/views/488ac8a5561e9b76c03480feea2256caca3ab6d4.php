<?php
    $rowGrid = 1;
    if(isset($row) && $row == '2'){
        $rowGrid = 2;
    }
?>

<?php if(isset($border) && $border == 'no'): ?>
        <div class="container flex flex-col gap-5">
<?php else: ?>
    <div class="container flex flex-col gap-5 p-8 border border-gray-200 rounded-lg">
<?php endif; ?>
    <div class="flex justify-between items-center">
        <p class="text-xl font-bold"><?php echo e($heading); ?></p>
        <?php if(!isset($border)): ?>
            <a href="#" class="text-md font-medium text-primary-500">Lihat Semua</a>
        <?php endif; ?>
    </div>
    <div class="grid grid-cols-5 gap-8">
        <?php for($i=0; $i<($rowGrid * 5); $i++): ?>
            <?php echo $__env->make('../components/card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endfor; ?>
    </div>
</div><?php /**PATH /home/theman49/Project/WAWSEWA/resources/views/components/section-card.blade.php ENDPATH**/ ?>